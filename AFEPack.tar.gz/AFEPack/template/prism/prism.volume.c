double prism_volume(double ** v)
{
	return 1.0;
};
