/**********************************************
* interval.volume.c
*/

double interval_volume(double ** v)
{
	return (v[1][0] - v[0][0]);
}

/*
* end of file
*********************************************/
