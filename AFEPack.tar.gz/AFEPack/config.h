/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the `dl' library (-ldl). */
#define HAVE_LIBDL 1

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the `tbb' library (-ltbb). */
#define HAVE_LIBTBB 1

/* Name of package */
#define PACKAGE "afepack"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "rli@math.pku.edu.cn"

/* Define to the full name of this package. */
#define PACKAGE_NAME "AFEPack"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "AFEPack 1.8"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "afepack"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.8"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "1.8"
